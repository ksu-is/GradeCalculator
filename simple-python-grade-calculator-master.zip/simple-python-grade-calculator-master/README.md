# simple-python-grade-calculator
A simple GUI grade calculator using Python and tkinter

To use, please download any version of Python 3: https://www.python.org/downloads/